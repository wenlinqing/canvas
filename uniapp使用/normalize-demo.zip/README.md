# normalize-demo

用于解决 String.prototype.normalize 的兼容性问题

参考此 Demo 在 App.vue 引入 unorm.js 即可。