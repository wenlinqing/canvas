#coding:utf-8

from selenium import webdriver
import time
import re

chrome = r'C:\Users\Administrator\Desktop\dist\chromedriver.exe'
header = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'}

# url = 'https://www.2-class.com/'
resultList = [{"question": "1.根据《中华人民共和国刑法》，毒品是指鸦片、海洛因、甲基苯丙胺（冰毒）、吗啡、大麻、可卡因，以及国家规定管制的其他能够使人形成瘾癖的（  ）和精神药品。", "answer": "C"}, {"question": "2.毒品的分类方式多种多样，从毒品的来源来看，毒品可分为天然毒品、（  ）、合成毒品。", "answer": "A"}, {"question": "3. 禁毒是全社会的共同责任。对于中学生而言，下列做法正确的是：", "answer": "B"}, {"question": "4. 阿片类毒品是从罂粟中提取的生物碱及体内外的衍生物。下列毒品中不属于阿片类毒品的是：", "answer": "C"}, {"question": "5. 毒品祸害无穷，不仅严重损害吸毒者本人的身体健康，对吸毒者的家庭和整个社会秩序都造成了严重的打击，吸毒的危害包括：", "answer": "D"}, {"question": "6. 鸦片，又叫阿片，俗称大烟，源于罂粟植物的（  ），其所含主要生物碱是吗啡。鸦片因产地不同，呈黑色或褐色；有氨味或陈旧尿味，味苦，气味强烈。鸦片最初是作为药用，主要用于镇咳、止泻等。吸食者初吸时会感到头晕目眩、恶心或头痛，多次吸食就会上瘾。", "answer": "B"}, {"question": "7. 新精神活性物质（New Psychoactive Substances，简称NPS），是不法分子为逃避打击而对列管毒品进行化学结构修饰所得到的毒品类似物，具有与管制毒品相似或更强的兴奋、致幻、麻醉等效果，这一概念于2013年在《世界毒品报告》中被首次提出，下列关于新精神活性物质的说法正确的是：", "answer": "D"}, {"question": "8.下列哪个选项全部是新精神活性物质？", "answer": "A"}, {"question": "9. LSD, 化学名称为D-麦角二乙胺，于1938年被首次合成，是一种强效（  ）。", "answer": "C"}, {"question": "10. 加强禁毒工作，治理毒品问题，对深入推进平安中国、法治中国建设，维护国家长治久安，保障人民群众健康幸福，实现“两个一百年”奋斗目标和中华民族伟大复兴的中国梦，具有十分重要的意义。作为一名中学生，可以为禁毒工作做些什么？", "answer": "D"}, {"question": "11. “国际禁毒日”是每年的（  ）。", "answer": "B"}, {"question": "12.珍爱生命，远离毒品。青少年要积极学习毒品知识，增强防毒拒毒意识，主动对毒品说“不”。下列有关毒品的说法正确的是？", "answer": "D"}, {"question": "13. 我国的“毒品”一词有着深远的历史渊源，是国人在百年来与毒品不懈抗争中的创造成果。我国首次对 “毒品”一词作出清晰定义的法律文本是：", "answer": "A"}, {"question": "14.毒品问题不是一个国家、一个民族的问题，而是全人类所面临的挑战。各国应当紧密团结在一起，携手应对毒品问题。目前，我国已加入的三大禁毒国际公约是：", "answer": "D"}, {"question": "15. 可卡因是用（  ）制成的。", "answer": "B"}, {"question": "16. 丧尸药、浴盐、土冰，这些都是同一类毒品的俗称，它的真正名称是（  ）", "answer": "B"}, {"question": "17. 王某在某地购得15克海洛因藏在家中准备自己吸食，后被公安机关查获，王某的行为构成了什么罪？", "answer": "B"}, {"question": "18. （  ）要依法加强涉毒演艺人员参加演出管理，推进娱乐服务场所毒品预防工作，支持创作优秀禁毒文化作品。", "answer": "B"}, {"question": "19. 吸毒，也称“药物滥用”，就是出于（  ）目的，通过注射、口服、鼻吸或其他方式将毒品摄入人体的行为。", "answer": "A"}, {"question": "20. 麻黄碱是从（  ）中提取的 。", "answer": "B"}, {"question": "21. 不满十六周岁的未成年人吸毒成瘾严重的，可以不适用（  ）。", "answer": "A"}, {"question": "22.第一次将毒品犯罪规定为国际犯罪的公约是（  ）。", "answer": "D"}, {"question": "23. “金新月”国际毒源地是指以下哪几个国家的交界地带？", "answer": "B"}, {"question": "24. 世界上第一个国际禁毒公约是（  ）。", "answer": "B"}, {"question": "25.下列有关毒品的认识错误的是：", "answer": "D"}, {"question": "26. 下面关于大麻的说法哪个是错误的？（  ）", "answer": "D"}, {"question": "27. γ-羟基丁酸，又称GHB，是一种无色无味的液体，由于它可以被轻易地放入饮料之中交给不知情的受害人使用，且受害人经常会不记得遭受过攻击，所以被称为“液体迷魂药”“迷奸水”。", "answer": "A"}, {"question": "28.（  ）是迷幻蘑菇中的主要成分，这种物质是一种血清素受体激动剂。在血清素缺席的场合，能够刺激一些受体，使人产生做梦一样的幻觉。", "answer": "A"}, {"question": "29.（  ），又称“阿拉伯茶”“东非罂粟”等。原产于非洲及阿拉伯半岛，主要活性成分为卡西酮、去甲伪麻黄碱等，具有兴奋和轻微致幻作用。滥用会出现抑郁、烦躁等症状。", "answer": "A"}, {"question": "30. 毒品是使用后能够产生（  ）的物质。", "answer": "B"}, {"question": "31. 身体脱毒只是戒毒过程的第一步，最根本上的是要彻底摆脱（  ），才能达到彻底康复。", "answer": "C"}, {"question": "32. 合成毒品直接作用于人的（  ）。", "answer": "C"}, {"question": "33. 毒品预防教育的首要重点对象是（  ）。", "answer": "B"}, {"question": "34. 当发现有人可能正在吸毒或实施涉及毒品的违法犯罪行为时，应该（  ）。", "answer": "A"}, {"question": "35. 当有人威胁我们吸毒时，要将情况主动告知家长和学校，或者打110报警，寻求帮助。", "answer": "A"}, {"question": "36. 一个完整的戒毒过程，包含（  ）。", "answer": "A"}, {"question": "37. 当在你身边出现毒品时，正确的做法是（  ）。", "answer": "C"}, {"question": "38. 吸毒人员既是病人又是（  ）。", "answer": "B"}, {"question": "39. 国家鼓励公民、组织开展公益性的禁毒宣传活动。", "answer": "A"}, {"question": "40. 国家严格管制戒毒药品的研究、生产、供应和使用。", "answer": "A"}, {"question": "41. 海洛因的滥用方式有（  ）。", "answer": "D"}, {"question": "42. 吸食海洛因，如采取静脉注射的方式，1至2次就可能成瘾。", "answer": "A"}, {"question": "43. 你的好朋友在娱乐场所给了你一种样子像糖果一样的东西，说特别好玩，让你尝尝。你的选择应该是：", "answer": "C"}, {"question": "44. 你的同学或者好朋友把你介绍给他的朋友们，这些人私密地聚在某人家里或者类似娱乐场所的地方，使用一些粉末、片剂或者类似香烟的东西，还请你品尝，你恰当的拒绝方式应该是（  ）。", "answer": "D"}, {"question": "45. 你认为一个家庭如何才能“远离毒品”？", "answer": "A"}, {"question": "46. 贩卖毒品负刑事责任的年龄是（  ）。", "answer": "C"}, {"question": "47. 青少年如何防止吸毒？", "answer": "D"}, {"question": "48. 青少年吸毒的原因是什么？", "answer": "D"}, {"question": "49. 如果有人在我们周围大量生产制造冰毒，很容易产生大量刺鼻的刺激性气味。这种说法正确吗？", "answer": "A"}, {"question": "50. 吸毒人员的毒品滥用方式多样，有更大的艾滋病传播风险。为了引起人们更广泛的关注，世界卫生组织将每年（  ）定为“世界艾滋病日”。", "answer": "D"}, {"question": "51. 在机场或火车站安检之前，有陌生人很着急地请你帮忙带个小书包，说书包里是“救命药”，飞机抵达或火车到站后，有人会来取这个小书包，还要给你一些酬金。你该怎么做？", "answer": "B"}, {"question": "52. 合成大麻素类物质是（  ）", "answer": "C"}, {"question": "53. 近几年，经过持续开展对青少年的毒品预防教育，我国35岁以下吸毒人员逐年减少。", "answer": "A"}, {"question": "54. 健康生活方式有？", "answer": "D"}, {"question": "55. 2019年5月1日起，我国将（  ）类物质列入非药用类麻醉药品和精神药品管制品种增补目录。", "answer": "C"}, {"question": "56. 止咳水通常含有可待因、麻黄碱等成分，（  ）服用可形成心理依赖，戒断症状类似海洛因。", "answer": "A"}, {"question": "57. 要构筑良好的拒毒心理防线只需做到正确把握好奇心，抵制不良诱惑即可。", "answer": "B"}, {"question": "58. 田某发现，在美国留学期间结识的朋友劳伦，经常在微信朋友圈出售一些号称化学合成的糖果、巧克力和“叶子”味的烟弹，这些很有可能含有毒品（  ）。", "answer": "D"}, {"question": "59. 远离毒品的自我保护方法有：", "answer": "D"}, {"question": "60. 制定《中华人民共和国禁毒法》的目的是：", "answer": "D"}, {"question": "61.中学生应该怎样做才能远离毒品、拒绝毒品？", "answer": "D"}, {"question": "62. 身边的亲戚、朋友、同学或者家长都吸烟，他们递烟给你，你不要，有人说偶尔体验一下没关系，你最好的应对方式应该是（  ）。", "answer": "D"}, {"question": "63. 安定有助于睡眠，可以擅自服用，不需医生指导使用，也不会对身体造成什么危害。", "answer": "B"}, {"question": "64. 为吸毒者提供房间、打火机、吸管等吸毒场所、工具，但自己并不吸毒，所以不用承担法律责任。这种说法：", "answer": "B"}, {"question": "65. 近年来市场上不断涌现一些“新精神活性物质”，它们的使用效果和某些毒品相似，但却没有被国家管制为毒品。由于未被国家管制，所以我们可以尝试使用这种物质。", "answer": "B"}, {"question": "66. 当前要不断推进禁毒宣传教育的理念思路、内容形式、方法手段改革创新，提高传播力、引导力和影响力，增强（  ）。", "answer": "D"}, {"question": "67. 当前要坚持关口前移、预防为先，从根本上遏制吸毒人员滋生，从源头上（  ）。", "answer": "B"}, {"question": "68. 为防范利用寄递渠道贩毒问题，国家邮政局要求物流寄递企业严格落实“（  ）、寄件验视、过机安检”三项制度。", "answer": "C"}, {"question": "69. 下面表述正确的是？（  ）", "answer": "D"}, {"question": "70. 禁毒民警检查某娱乐场所时，被两男子的交谈内容“吸引”，不时可以听到“壶”“溜了几口”等话语，通过这些敏感词，民警即时判断出来，这极有可能是两名吸食（  ）人员。", "answer": "A"}, {"question": "71. （  ）地区是我国境外合成毒品的主要来源。", "answer": "A"}, {"question": "72. 2019年8月29日，青岛海关首次查获了10盒1000粒被误传为“聪明药”的一类管制精神药物（  ）。", "answer": "A"}, {"question": "73. 下列选项中属于吸毒成瘾表现的是（  ）。", "answer": "D"}, {"question": "74. 下列选项中属于毒品的是（  ）。", "answer": "D"}, {"question": "75. 下列选项中不属于毒品特征的是（  ）。", "answer": "D"}, {"question": "76. 不是艾滋病传播途径的是（  ）", "answer": "D"}, {"question": "77. 下列属于合成毒品的是（  ）。", "answer": "C"}, {"question": "78. 下列说法正确的是（  ）。", "answer": "A"}, {"question": "79. 下列物品中不属于毒品的是（  ）。", "answer": "C"}, {"question": "80. 下列关于戒毒说法正确的是（  ）。", "answer": "C"}, {"question": "81. 吸食过量大麻可发生意识不清、产生幻觉等。", "answer": "A"}, {"question": "82. 吸食合成毒品危害比传统毒品要小。", "answer": "B"}, {"question": "83. 吸食冰毒以后驾驶车辆，容易造成情绪冲动及过度兴奋，从而导致行为失控极易引发严重交通事故。", "answer": "A"}, {"question": "84. 吸毒者在今后的人生道路上应该选择的正确生活态度是（  ）。", "answer": "D"}, {"question": "85. 吸毒者不健康的心理有盲目从众、好奇、爱慕虚荣、赶时髦、追求刺激和享乐、赌气或逆反、无知和轻信、自暴自弃等。", "answer": "A"}, {"question": "86. 我们的爸爸、爷爷都可以喝酒，所以我们未成年人也可以喝酒。", "answer": "B"}, {"question": "87. 我们在网络上和陌生人交流和交友的时候，应该保持警惕心，不能轻易泄露自己的个人信息。", "answer": "A"}, {"question": "88. 吸毒成瘾不仅是身体上会对毒品产生依赖，更严重的是在心理上对毒品产生依赖。", "answer": "A"}, {"question": "89. 我国禁毒工作的治本之策是（  ）。", "answer": "A"}, {"question": "90. 长期吸食以后，情绪亢奋冲动。就算是停止复吸，戒断很久以后，都容易出现幻听、幻觉、被害妄想等稽延性戒断症状。这是（）毒品的精神病态特征。", "answer": "C"}, {"question": "91. 禁毒工作要不断巩固深化（  ）成果，助力乡村振兴。", "answer": "A"}, {"question": "92. 关于“上头电子烟”，下列说法正确的是（  ）。", "answer": "D"}, {"question": "93. 有人劝说小明一起“嗨气球”，并且告诉小明吸了之后会有“上头”的感觉。对于该案例，下列说法正确的是（）。", "answer": "D"}, {"question": "94. 小明随家人出国旅游，在国外的时候，有人邀请小明一起抽大麻烟，并且告诉小明在国外抽大麻是合法的。对于该案例，下列说法正确的是（）。", "answer": "D"}, {"question": "95. 小明随家人搭乘飞机外出旅游，进机场的时候，有陌生人请小明帮忙，让小明偷偷把一小包“小树枝”贴身隐藏带过安检，并承诺事后给小明一大笔钱。对于该案例，下列说法正确的是（）。", "answer": "D"}, {"question": "96. 关于毒品犯罪，下列说法正确的是（）。", "answer": "D"}, {"question": "97. 2021年我国新列管（  ）易制毒化学品", "answer": "C"}, {"question": "98. 下列属于我国2021年新列管易制毒化学品的有（  ）", "answer": "B"}, {"question": "99. 下列属于非药用类麻醉药品和精神药品的有（  ）。", "answer": "C"}, {"question": "100. 国家鼓励吸毒成瘾人员自行戒除毒瘾。对自愿接受戒毒治疗的吸毒人员，公安机关对其原吸毒行为不予处罚。（  ）", "answer": "A"}, {"question": "101. 《戒毒条例》第十八条明确规定，乡（镇）人民政府、城市街道办事处和社区戒毒工作应当采取下列措施管理、帮助社区戒毒人员：", "answer": "D"}, {"question": "102. 《中华人民共和国禁毒法》第三十八条规定。吸毒成瘾人员，有（  ）情形之一的，由县级以上人民政府公安机关作出强制隔离戒毒的决定。", "answer": "D"}, {"question": "103. 《中华人民共和国禁毒法》第三十一条规定，吸毒成瘾的认定办法，由国务院（）部门、（）部门、（）部门规定。", "answer": "D"}, {"question": "104. 20世纪末的奥林匹克竞技比赛中，为了赢得更好的比赛成绩，曾经一度被美国短跑、拳击等项目的运动员广泛滥用，并造成部分运动员最终患上急性心脏病或脑血管疾病引发猝死的物质是(  )。", "answer": "B"}, {"question": "105. 对下列涉毒人员，可以不予处罚的是（ ）。", "answer": "B"}, {"question": "106. 2021年3月，国家禁毒委员会命名了首批（  ）个全国禁毒示范城市。", "answer": "D"}, {"question": "107. 目前，我国共有（   ）个公安院校设有禁毒学本科专业。", "answer": "C"}, {"question": "108. 你的同学以认识朋友的名义邀请你参加聚会，在聚会现场让你尝试一下装在瓶子里的不明液体，说“不是毒品”“比较刺激”“不会上瘾”“大家都玩”。你应该选择怎么办？", "answer": "D"}]


def loadFile():
    try:
        questionList = []
        answerList = []
        resultList = []
        with open('123.txt', encoding='utf-8') as fl:
            # print(fl.read())
            for tt in fl.readlines():
                if(tt.strip() != ''):
                    # print(tt)
                    eachObj = {}
                    if(tt and tt.split('.')[0].isalnum() and int(tt.split('.')[0]) > 0):
                        eachObj['question'] = tt
                        questionList.append(eachObj)
                        # print(eachObj)

                    if('答案' in tt):
                        # print('tt=====', tt.strip().split("：")[1])
                        eachObj['answer'] = tt.strip().split("：")[1]
                        answerList.append(eachObj)

            # print('questionList====',questionList)
            # print('answerList====',answerList)

            for i,val in enumerate(questionList):
                # print(i,val)
                resultList.append(dict(val,**answerList[i]))

            print('resultList====', resultList)
    except Exception as e:
        print('eeeeeeeeee=',e)


# loadFile()

def eachQuestion(browser):
    # 提取页面问题
    question = browser.find_element_by_css_selector('#app > div > div.home-container > div > div > div.competiotion-exam-box-all > div.exam-box > div:nth-child(3) > div').text

    # question = '1.根据《中华人民共和国刑法》，毒品是指鸦片、海洛因、甲基苯丙胺（冰毒）、吗啡、大麻、可卡因，以及国家规定管制的其他能够使人形成瘾癖的（  ）和精神药品。'
    if '①' in question:
        question = question.split('①')[0].strip()

    question = question.strip().replace('：','').replace('（', '').replace('）', '').replace('  ','').replace('。','').replace('、','').replace('，','').replace('“','').replace('”','').replace(' ','').replace('()','').replace('　','')
    print('question=======', question)
    qq = question

    result = ''
    for oo in resultList:
        # print(oo['question'])
        qqqq = oo['question'].strip().replace('：','').replace('（', '').replace('）', '').replace(' ','').replace('。','').replace('、','').replace('，','').replace('“','').replace('”','').replace(' ','').replace('()','').replace('　','')
        qqqq = qqqq.split('.')[1]
        # print('qqqq====', qqqq)

        if len(qq) == len(qqqq) and (qq in qqqq):
            # print('answer', oo['answer'])
            result = oo['answer']
            break  # 停止循环

    print('result result', result)

    ans = browser.find_elements_by_css_selector('#app > div > div.home-container > div > div > div.competiotion-exam-box-all > div.exam-box > div:nth-child(4) > div > label')
    for a in ans:
        pageAns = a.find_element_by_css_selector('span:nth-child(2) > div').text.split('、')[0]
        # print('pageAns===',pageAns)
        if pageAns == result:
            a.click()
            break # 停止循环

    time.sleep(0.5)

    # 下一题
    browser.find_element_by_class_name('ant-btn-primary').click()



def openUrl(student):
    try:
        option = webdriver.ChromeOptions()
        option.add_argument('User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36"')
        option.add_argument("headless")
        browser = webdriver.Chrome(executable_path=chrome, options=option)
        # browser.set_page_load_timeout(15)

        browser.get("https://www.2-class.com/competition")
        # browser.maximize_window()
        time.sleep(1)
        browser.find_element_by_class_name('unlogin').click()
        # button = browser.find_element_by_class_name('ant-btn-primary')
        time.sleep(1)
        browser.find_element_by_id('account').send_keys(student[0])
        browser.find_element_by_id('password').send_keys(student[1])
        browser.find_element_by_css_selector('body > div:nth-child(13) > div > div.ant-modal-wrap > div > div.ant-modal-content > div > form > div > div > div > button').click()

        time.sleep(4)
        try:
            if browser.find_element_by_class_name('exam-box-title'):
                browser.find_element_by_class_name('ant-btn-primary').click()
                for i in range(0,20):
                    time.sleep(0.5)
                    eachQuestion(browser)

            print(student[0], '该学生已通过考试')
        except Exception as e:
            print('该学生已考试')
            with open('passed15.txt', 'a', encoding='utf-8') as p:
                print('str(student)===',str(student))
                p.write(str(student)+'\r')

        time.sleep(2)
        browser.quit()

    except Exception as e:
        print('eeeeeeeeeeeee=',e)
        print('重启浏览器  重启浏览器 重启浏览器')
        browser.quit()
        openUrl(student)


account = [
# ['xuyingying13302', 'syxx666888'], ['chenjunwen4404', 'syxx666888'], ['shijiazheng180', 'syxx666888'], ['laijiahui2629', 'syxx666888'], ['denglinqi108', 'syxx666888'], ['liaobinyi61', 'syxx666888'], ['yaoxintong1824', 'syxx666888'], ['baizhibo308', 'syxx666888'], ['chenziyi36172', 'syxx666888'], ['wangbinglin1163', 'syxx666888'], ['zhouyuhang12834', 'syxx666888'], ['zhonghao9206', 'syxx666888'], ['zhanghuanhuan5726', 'syxx666888'], ['liujiale43356', 'syxx666888'], ['panyuchen5179', 'syxx666888'], ['dengwensong102', 'syxx666888'], ['chenxin91518', 'syxx666888'], ['liyinuo24992', 'syxx666888'], ['laiyitao235', 'syxx666888'], ['laikun428', 'syxx666888'], ['zhengbowen14976', 'syxx666888'], ['longrui2753', 'syxx666888'], ['chenshengjie3675', 'syxx666888'], ['dengrui7842', 'syxx666888'], ['wenziruo27', 'syxx666888'], ['huangchenglei246', 'syxx666888'], ['yangruyi5301', 'syxx666888'], ['xiongchenghao310', 'syxx666888'], ['zhanglei65319', 'syxx666888'], ['liaokai2614', 'syxx666888'], ['liuxinyi107862', 'syxx666888'], ['liaoming1309', 'syxx666888'], ['yewenting922', 'syxx666888'], ['dengrunhua59', 'syxx666888'], ['laiyuqi814', 'syxx666888'], ['huangjinyao835', 'syxx666888'], ['xuyuru986', 'syxx666888'], ['laishuhuan43', 'syxx666888'], ['hexinrui5452', 'syxx666888'], ['fuyaxin1457', 'syxx666888'], ['liuzhenyan1684', 'syxx666888'], ['xieshiyu4162', 'syxx666888'], ['wenjing14181', 'syxx666888'], ['chenrouyan250', 'syxx666888'], ['chenziyi43405', 'syxx666888'], ['laitaohan1', 'syxx666888'], ['zhangyawen16038', 'syxx666888'], ['zhanglilin1304', 'syxx666888'], ['zhangshuxian3265', 'syxx666888'], ['cengxian1068', 'syxx666888'], ['fanzixuan3782', 'syxx666888'], ['chenjunbo1742', 'syxx666888'], ['huangyuzhe1533', 'syxx666888'], ['chenchuwei449', 'syxx666888'], ['luoxiwen824', 'syxx666888'], ['chenshihan6785', 'syxx666888']



['wenxinyu4656', 'syxx666888'], ['xiongkaiyi96', 'syxx666888'], ['wenhui599', 'syxx666888']












]



for ea in account:
    print(ea)
    openUrl(ea)
    time.sleep(1)

print('学生名单执行完毕')
# openUrl()























