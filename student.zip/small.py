#coding:utf-8

from selenium import webdriver
import time
import re

chrome = r'C:\Users\Administrator\Desktop\dist\chromedriver.exe'
header = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36'}

# url = 'https://www.2-class.com/'

resultList = [{'question': '1.“国际禁毒日”是每年的（  ）。', 'answer': ['B']}, {'question': '2.传统毒品一般是指鸦片、海洛因、大麻等流行较早的毒品。', 'answer': ['A']}, {'question': '3.药品可以随意服用，不需要遵医嘱。', 'answer': ['C']}, {'question': '4.“金三角”是指泰国、缅甸、（  ）三国交界的地方（一个区域）。', 'answer': ['A']}, {'question': '5. “摇头丸”是苯丙胺类的衍生物，属中枢神经（  ）。', 'answer': ['B']}, {'question': '6.甲基苯丙胺因其纯品无色透明，像冰一样，故俗称“冰毒”。', 'answer': ['A']}, {'question': '7.吸食毒品是违法行为，不是犯罪行为。', 'answer': ['A']}, {'question': '8.《中华人民共和国禁毒法》规定，教育行政部门、（  ）应当将禁毒知识纳入教育、教学内容，对学生进行禁毒宣传教育。', 'answer': ['A']}, {'question': '9.《中华人民共和国禁毒法》自（  ）起施行。', 'answer': ['C']}, {'question': '10.K粉呈白色结晶粉末状，易溶于水，可勾兑进饮料和酒水中。', 'answer': ['A']}, {'question': '11.从毒品流行的时间顺序看，可分为传统毒品和新型毒品。传统毒品一般是指鸦片、海洛因、大麻等流行较早的毒品。', 'answer': ['A']}, {'question': '12.从医学角度看，吸毒成瘾是一种疾病，是（  ）。', 'answer': ['D']}, {'question': '13.当发现有人可能正在吸毒或实施涉及毒品的违法犯罪行为时，应该（  ）。', 'answer': ['A']}, {'question': '14.当有人威胁我们吸毒时，要将情况主动告知家长和学校，或者打110报警，寻求帮助。', 'answer': ['A']}, {'question': '15.当有人以各种借口引诱你吸食毒品或尝试可能是毒品的药丸时，正确的做法是（  ）。', 'answer': ['A']}, {'question': '16.当在你身边出现毒品时，正确的做法是（  ）。', 'answer': ['C']}, {'question': '17.毒品区别于其他毒物的自然属性是（  ）。', 'answer': ['B']}, {'question': '18.毒品是使用后能够产生依赖性的物质。', 'answer': ['A']}, {'question': '19.《中华人民共和国禁毒法》第四条规定：禁毒工作实行（  ）为主，综合治理，禁种、禁制、禁贩、禁吸并举的方针。', 'answer': ['A']}, {'question': '20.毒品与药品，往往具有双重属性，合法为人解除病痛的就是药品。', 'answer': ['A']}, {'question': '21.止咳水不能随便乱用，需要遵医嘱。', 'answer': ['A']}, {'question': '22.二十世纪（  ），中国获得“无毒国”美誉近三十年。', 'answer': ['B']}, {'question': '23.各级人民政府应当建立毒品违法犯罪举报制度。', 'answer': ['A']}, {'question': '24.根据（  ）需要，依法可以生产、经营、使用、储存、运输麻醉药品和精神药品。', 'answer': ['A']}, {'question': '25.在日常生活中防毒要做到：一是不要听人蛊惑，受人引诱；二是不要与吸毒、贩毒者为伍；三是不要随意接受陌生人的馈赠； 四是（  ）。', 'answer': ['B']}, {'question': '26.医学上习惯称吸毒为药物滥用。', 'answer': ['A']}, {'question': '27.国家鼓励公民、组织开展公益性的禁毒宣传活动。', 'answer': ['A']}, {'question': '28.合成毒品直接作用于人的（  ）。', 'answer': ['C']}, {'question': '29.各级各类学校必须开设禁毒专题教育课，将禁毒教育列为学校教育的内容。', 'answer': ['A']}, {'question': '30.戒毒人员在（  ）等方面不受歧视。有关部门、组织和人员应当在这些方面对戒毒人员给予必要的指导和帮助。', 'answer': ['D']}, {'question': '31.戒毒是一个长期的过程，包括生理脱毒与医学治疗、（  ）、善后辅导与回归社会三个阶段。', 'answer': ['B']}, {'question': '32.“金新月”国际毒源地是指以下哪几个国家的交界地带？', 'answer': ['B']}, {'question': '33.咖啡因是从茶叶、咖啡果中提炼出来的一种生物碱，是国家管制的精神药品，所以人们喝茶、喝咖啡的行为是吸毒。', 'answer': ['B']}, {'question': '34.麦角二乙胺（LSD），俗称“邮票”、“贴纸”，是一种强烈的致幻剂。', 'answer': ['A']}, {'question': '35.关于“笑气”，下列说法正确的是：（  ）', 'answer': ['A', 'B', 'C', 'D']}, {'question': '36.南美的（  ）、秘鲁、玻利维亚是可卡因的最大生产基地，俗称“银三角”。', 'answer': ['C']}, {'question': '37.李某发现儿子小强吸毒后，便将其关在家中，并与家人轮流看守令其戒毒。起初，断了毒品的小强呼天喊地，半个月后，小强又恢复了正常。试问小强是否已全部戒除毒瘾？（  ）', 'answer': ['B']}, {'question': '38.你的好朋友在娱乐场所给你一种样子像糖果一样的东西，说特别好玩，让你尝尝。你的选择应该是：（  ）', 'answer': ['C']}, {'question': '39.有人引诱你吸食一些不明来源的小零食、饮料等，你应该如何应对？', 'answer': ['B']}, {'question': '40.你认为一个家庭如何才能“远离毒品”？（  ）', 'answer': ['A']}, {'question': '41.青少年如何避免吸毒？（  ）', 'answer': ['D']}, {'question': '42.青少年吸毒的原因是什么？（  ）', 'answer': ['D']}, {'question': '43.珍爱生命，远离毒品，要做到（  ）', 'answer': ['A', 'B', 'C', 'D']}, {'question': '44.人们常说“毒品猛于虎”，毒品的危害除了对身心的危害，严重摧残吸毒者的身体之外，还包括（  ）。', 'answer': ['D']}, {'question': '45.如果有同学或好朋友吃了一些东西以后，发生昏厥、呕吐或是抽搐等不适症状，我们可以拨打120急救电话。', 'answer': ['A']}, {'question': '46.身体脱毒只是戒毒过程的第一步，最根本上的是要彻底摆脱（  ），才能达到彻底康复。', 'answer': ['C']}, {'question': '47.王某在自己花盆里种植5株罂粟用来欣赏美丽花朵，这是允许的 。', 'answer': ['B']}, {'question': '48.世界卫生组织将每年（  ）定为“世界艾滋病日”。', 'answer': ['D']}, {'question': '49.毒品预防教育的重点对象是（  ）。', 'answer': ['A']}, {'question': '50.吸毒的危害有哪些方面？（  ）', 'answer': ['D']}, {'question': '51.吸毒会损害人的呼吸系统、消化系统、心血管系统、免疫系统和神经系统，感染各种疾病。', 'answer': ['A']}, {'question': '52.吸毒行为可以通过采集吸毒嫌疑人的血液、尿液、毛发等检测出来。', 'answer': ['A']}, {'question': '53.吸毒人员是违法者，也是（  ）。', 'answer': ['A']}, {'question': '54.大剂量吸食大麻可造成幻觉、妄想、精神失常。', 'answer': ['A']}, {'question': '55.小明今年上五年级，沉迷于网络游戏，然后到黑网吧去上网，结交了不良的朋友，最后染上了烟瘾和学会了吸毒。这个故事告诉我们什么道理？（  ）', 'answer': ['D']}, {'question': '56.摇头丸主要出现在慢摇吧、迪厅等娱乐场所，青少年应拒绝去这些场所。（  ）', 'answer': ['A']}, {'question': '57.远离毒品的自我保护方法有（  ）。', 'answer': ['D']}, {'question': '58.跳跳糖、奶茶、咖啡包等不是毒品，但是毒贩会把毒品伪装成“跳跳糖、奶茶、咖啡包”等，我们要保持警惕。', 'answer': ['A']}, {'question': '59.小学生应该怎样做才能远离毒品、拒绝毒品？（  ）', 'answer': ['A', 'B', 'C', 'D']}, {'question': '60.身边的亲戚、朋友、同学或者家长都吸烟，他们递烟给你，你不要，有人说偶尔体验一下没关系，你最好的应对方式应该是（  ）。', 'answer': ['D']}, {'question': '61.世界上三大毒品产地中哪一个不在亚洲？ ', 'answer': ['C']}, {'question': '62.大麻是目前世界上滥用人数最多的毒品。', 'answer': ['A']}, {'question': '63.为了安全起见，我们应该拒绝陌生人给的糖果、点心或任何饮料。（  ）', 'answer': ['A']}, {'question': '64.“虎门销烟”是哪一天开始的（  ）。', 'answer': ['A']}, {'question': '65.未成年人的父母或者其他监护人应当对未成年人进行毒品危害的教育，防止其吸食、注射毒品或者进行其他毒品违法犯罪活动。', 'answer': ['A']}, {'question': '66.我国近代史中的第一次“鸦片战争”是哪国发起的？ ', 'answer': ['C']}, {'question': '67.我国禁毒工作的治本之策是（  ）。', 'answer': ['A']}, {'question': '68.我们的爸爸、爷爷都可以喝酒，所以作为小学生我们也可以喝酒。（  ）', 'answer': ['B']}, {'question': '69.吸毒会败坏社会风气，腐蚀人的灵魂，摧毁民族精神。', 'answer': ['A']}, {'question': '70.吸毒人群的意外死亡率较一般人群高。', 'answer': ['A']}, {'question': '71.吸毒人员身体消瘦是一种常态，而非病态，所以吸食毒品能有效减肥。', 'answer': ['B']}, {'question': '72.吸毒如果仅仅偶尔吸一两次，一般都不会上瘾。这种说法（  ）', 'answer': ['B']}, {'question': '73.吸毒者不健康的心理有盲目从众、好奇、爱慕虚荣、赶时髦、追求刺激和享乐、赌气或逆反、无知和轻信、自暴自弃等。', 'answer': ['A']}, {'question': '74.吸食冰毒以后马上驾驶车辆，容易造成情绪冲动及过度兴奋，从而极易引发严重交通事故。', 'answer': ['A']}, {'question': '75.吸食注射毒品成瘾的，应当戒除毒瘾。', 'answer': ['A']}, {'question': '76.吸烟会使肺癌的发生几率增加，诱发呼吸系统疾病，从而威胁人们的身体健康。', 'answer': ['A']}, {'question': '77.下面表述正确的是？（  ）', 'answer': ['D']}, {'question': '78.学生也有一份禁毒的责任。', 'answer': ['A']}, {'question': '79.要拒绝毒品，我们除了要知道什么是毒品、知道毒品极易成瘾、知道毒品的危害，还要（  ）。', 'answer': ['D']}, {'question': '80.以下属于生活技能教育主要内容的是（  ）。', 'answer': ['D']}, {'question': '81.长期抽烟、喝酒也会产生生理依赖和心理依赖', 'answer': ['A']}, {'question': '82.出于观赏的目的，种植大麻、古柯或罂粟就是合法的。以上说法正确吗?', 'answer': ['B']}, {'question': '83.止咳露（或止咳水）只是一种常见的中成药，大量服用不会形成药物依赖。这种说法（  ）。', 'answer': ['B']}, {'question': '84.制定《中华人民共和国禁毒法》的目的是：预防和惩治毒品违法犯罪行为，保护公民身心健康，维护社会秩序。', 'answer': ['A']}, {'question': '85.学校毒品预防教育的目标是（  ）', 'answer': ['C']}, {'question': '86.学校是毒品预防教育的主阵地，课堂是主渠道', 'answer': ['A']}, {'question': '87.新精神活性物质又称：', 'answer': ['D']}, {'question': '88.不是艾滋病的传播途径的是（  ）', 'answer': ['D']}, {'question': '89.不健康的生活方式有？', 'answer': ['D']}, {'question': '90.国家禁毒办依托全国青少年毒品预防教育数字化平台，建立科学评比遴选机制，鼓励各地开发制作各类禁毒宣传教育资料，推送全国（  ）。', 'answer': ['A']}, {'question': '91.结交朋友越多越好吗？（  ）', 'answer': ['C']}, {'question': '92.高雅情趣是（  ）向上的生活情趣，能催人上进，改变人的精神面貌，提高人的文化修养，使生活更加充实且富有意义。', 'answer': ['D']}, {'question': '93. 目前，（  ）地区是对我国危害最大的毒品来源地。', 'answer': ['A']}, {'question': '94. 麻醉药品和精神药品属于列管物质，具有（  ）属性。', 'answer': ['C']}, {'question': '95. 下列属于我国整类列管的非药用类麻醉药品和精神药品的有（  ）', 'answer': ['C']}, {'question': '96. 芬太尼属于哪种药品？', 'answer': ['B']}, {'question': '97. 今年6月至11月，中央宣传部、中央网信办、教育部、国家禁毒办等十个部门联合制定方案，在全国集中组织开展防范毒品滥用宣传教育活动。方案明确指出，我国目前列管的麻精药品数量和整类列管的物质数量分别是（  ）。', 'answer': ['D']}, {'question': '98. 列入下列哪个目录的物质如果被滥用就是吸毒？', 'answer': ['D']}, {'question': '99. 合成毒品“麻古”是泰语的音译，其主要成分是(  )', 'answer': ['A']}, {'question': '100. 可卡因的原植物是(  )，曾经是古代美洲原住民的提神草。', 'answer': ['D']}, {'question': '101. 1909年2月1日，中、日、英、法、俄、德、美、葡等国召开禁毒会议，拉开了国际性禁毒活动的序幕，这次会议的举办地是(  )。', 'answer': ['A']}, {'question': '102. 近年来，各地禁毒部门积极推进现代科技应用，已经广泛应用了（  ）、（  ）等手段进行毒情监测预警。', 'answer': ['A']}, {'question': '103. 国家禁毒委员会成立于（   ）年，现有公安部、教育部等（   ）个成员单位。', 'answer': ['A']}, {'question': '104. 第一届全国青少年禁毒知识竞赛于（   ）年举办。', 'answer': ['B']}]


def loadFile():
    try:
        questionList = []
        answerList = []
        resultList = []
        with open('123.txt', encoding='utf-8') as fl:
            # print(fl.read())
            for tt in fl.readlines():
                if(tt.strip() != ''):
                    # print(tt)
                    eachObj = {}
                    if(tt and tt.split('.')[0].isalnum() and int(tt.split('.')[0]) > 0):
                        eachObj['question'] = tt
                        questionList.append(eachObj)
                        # print(eachObj)

                    if('答案' in tt):
                        # print('tt=====', tt.strip().split("：")[1])
                        eachObj['answer'] = tt.strip().split("：")[1]
                        answerList.append(eachObj)

            # print('questionList====',questionList)
            # print('answerList====',answerList)

            for i,val in enumerate(questionList):
                # print(i,val)
                resultList.append(dict(val,**answerList[i]))

            print('resultList====', resultList)
    except Exception as e:
        print('eeeeeeeeee=',e)


# loadFile()

def eachQuestion(browser):
    # 提取页面问题
    question = browser.find_element_by_css_selector('#app > div > div.home-container > div > div > div.competiotion-exam-box-all > div.exam-box > div:nth-child(3) > div').text

    # question = '1.根据《中华人民共和国刑法》，毒品是指鸦片、海洛因、甲基苯丙胺（冰毒）、吗啡、大麻、可卡因，以及国家规定管制的其他能够使人形成瘾癖的（  ）和精神药品。'
    if '①' in question:
        question = question.split('①')[0].strip()

    question = question.strip().replace('：','').replace('（', '').replace('）', '').replace('  ','').replace('。','').replace('、','').replace('，','').replace('“','').replace('”','').replace(' ','').replace('()','').replace('　','')
    print('question=======', question)
    # print(resultList)

    qqFile = '当发现有人可能正在吸毒或实施涉及毒品的违法犯罪行为时，应该（  ）。'
    # qqFile.replace(' ','')
    # print(qqFile)
    qq = '当发现有人可能正在吸毒或实施涉及毒品的违法犯罪行为时，应该（  ）。'
    qq = question

    # print(re.match(qq, qqFile))

    result = ''
    for oo in resultList:
        # print(oo['question'])
        qqqq = oo['question'].strip().replace('：','').replace('（', '').replace('）', '').replace(' ','').replace('。','').replace('、','').replace('，','').replace('“','').replace('”','').replace(' ','').replace('()','').replace('　','')
        qqqq = qqqq.split('.')[1]
        # print('qqqq====', qqqq)

        if len(qq) == len(qqqq) and (qq in qqqq):
            # print('answer', oo['answer'])
            result = oo['answer']
            break  # 停止循环

    print('result result', result)

    ans = browser.find_elements_by_css_selector('#app > div > div.home-container > div > div > div.competiotion-exam-box-all > div.exam-box > div:nth-child(4) > div > label')
    for a in ans:
        pageAns = a.find_element_by_css_selector('span:nth-child(2) > div').text.split('、')[0].strip('.')[0]
        # print('pageAns===',pageAns)
        if pageAns in result:
            a.click()
            # print('a.click() a.click()')
            time.sleep(0.3)
            # break # 停止循环
            # print('a.click() a.click()')
        # else:
        #     while True:
        #         pass

    time.sleep(0.5)

    # 下一题
    browser.find_element_by_class_name('ant-btn-primary').click()



def openUrl(student):
    try:
        option = webdriver.ChromeOptions()
        option.add_argument('User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36"')
        option.add_argument("headless")
        browser = webdriver.Chrome(executable_path=chrome, options=option)
        # browser.set_page_load_timeout(15)

        browser.get("https://www.2-class.com/competition")
        # browser.maximize_window()
        time.sleep(1)
        browser.find_element_by_class_name('unlogin').click()
        # button = browser.find_element_by_class_name('ant-btn-primary')
        time.sleep(1)
        browser.find_element_by_id('account').send_keys(student[0])
        browser.find_element_by_id('password').send_keys(student[1])
        browser.find_element_by_css_selector('body > div:nth-child(13) > div > div.ant-modal-wrap > div > div.ant-modal-content > div > form > div > div > div > button').click()

        time.sleep(4)
        try:
            if browser.find_element_by_class_name('exam-box-title'):
                browser.find_element_by_class_name('ant-btn-primary').click()
                for i in range(0,20):
                    time.sleep(0.5)
                    eachQuestion(browser)

            print(student[0], '该学生已通过考试')
        except Exception as e:
            print('该学生已考试')
            print('str(student)===', str(student))
            # time.sleep(100)
            with open('passed.txt', 'a', encoding='utf-8') as p:
                p.write(str(student)+'\r')

        time.sleep(1)
        browser.quit()

    except Exception as e:
        print('eeeeeeeeeeeee=',e)
        print('重启浏览器  重启浏览器 重启浏览器')
        browser.quit()
        openUrl(student)
    # while True:
    #     pass


account =  []
#

for ea in account:
    print(ea)
    openUrl(ea)
    time.sleep(1)

print('学生名单执行完毕')
# openUrl()























