#coding:utf-8

from openpyxl import load_workbook


try:
    wb = load_workbook('student.xlsx')
    ws = wb.active
    max_row = ws.max_row

    account = []
    for row in ws.iter_rows(min_row=2, min_col=6, max_col=7):
        obj = []
        for cell in row:
            obj.append(cell.value)
            # print(cell.value,' ==== ', end='')

        account.append(obj)
        # print('')

    print('account =', account)
    print(len(account))
except Exception as e:
    print('eeeeeeeee',e)











