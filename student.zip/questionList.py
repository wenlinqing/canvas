
#coding:utf-8


def loadFile():
    try:
        questionList = []
        answerList = []
        resultList = []
        with open('small.txt', encoding='utf-8') as fl:
            # print(fl.read())
            for tt in fl.readlines():
                if(tt.strip() != ''):
                    # print(tt)
                    eachObj = {}
                    if(tt and tt.split('.')[0].isalnum() and int(tt.split('.')[0]) > 0):
                        eachObj['question'] = tt
                        questionList.append(eachObj)
                        # print(eachObj)

                    if('答案：' in tt  ):  # and len(tt.strip())==4
                        www = tt.strip().split("：")[1]
                        # print('tt=====', www)
                        eachObj['answer']=[]
                        for w in www:
                            # print('wwwww=', w)
                            eachObj['answer'].append(w)

                        # eachObj['answer'] = tt.strip().split("：")[1]
                        answerList.append(eachObj)

            # print('questionList====', questionList )
            # print('answerList====', answerList )

            for i,val in enumerate(questionList):
                # print(val,answerList[i])
                resultList.append(dict(val,**answerList[i]))

            print('resultList====', resultList)
            # for o in resultList:
            #     print('ooooooo=',o)
    except Exception as e:
        print('eeeeeeeeee=',e)


# 题库提取
loadFile()




